const config = {
  dataBase: {
    DATABASE: 'pecker',
    USERNAME: 'root',
    PASSWORD: '123456',
    PORT: '3306',
    HOST: 'localhost'
  }
}

module.exports = config